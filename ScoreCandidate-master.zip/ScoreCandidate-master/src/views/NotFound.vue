<template>
    <div class="not-found">
        <h1>Страница не найдена, поищите в другом месте... <i class="fas fa-ghost"></i></h1>
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style lang="scss" scoped>
    .not-found {
        text-align: center;
        padding-top: 50px;
    }
</style>